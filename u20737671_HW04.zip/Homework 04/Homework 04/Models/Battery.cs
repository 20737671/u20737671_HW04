﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Homework_04.Models
{
    public class Battery : Materials
    {

        private string BatteryType;

        public string BatteryType1 { get => BatteryType; set => BatteryType = value; }

        public Battery()
        {
            Name = "Battery";
            Description = "Home use batteries";
            Procedure = "Stripped of outside layer and discarded";
            BiodegradeTime = 100;
            PollutionPercentage = 3;
            BatteryType = "Lithium";

            getThreat();
            getPriority();
        }


        public Battery(string name, string description, string procedure, double biodegradeTime, double pollutionPercentage, int mPriority, int mThreat): base(name, description, procedure, biodegradeTime ,pollutionPercentage)
        {
        }

        public override double getThreat()
        {
            if (PollutionPercentage >= 4)
            {
                mThreat = 1;
                
            }
            else if(PollutionPercentage >= 8)
            {
                mThreat = 2;
            }
            else if (PollutionPercentage >= 12)
            {
                mThreat = 3;
            }
            else if (PollutionPercentage >= 16)
            {
                mThreat = 4;
            }
            return mThreat;
        }


        public override double getPriority()
        {
            if (BiodegradeTime >= 500)
            {
                mPriority = 2;

            }
            else if (BiodegradeTime >= 300)
            {
                mPriority = 4;
            }
            else if (BiodegradeTime >= 1000000)
            {
                mPriority = 6;
            }
            else if (BiodegradeTime >= 10000000000000000)
            {
                mPriority = 9;
            }
            return mPriority;
        }

        




        //public override string getName()
        //{
        //    string realName = Name;
        //    return realName;
        //}
        //public override string getDesc()
        //{
        //    string realDesc = Description;
        //    return realDesc;
        //}


        //public override string getProc()
        //{
        //    string realProc = Procedure;
        //    return realProc;
        //}

        //public override string getBioTime()
        //{
        //    string realBio = BiodegradeTime;
        //    return realBio;
        //}

        //public override string getPolPerc()
        //{
        //    string realPolPerc = PollutionPercentage;
        //    return realPolPerc;
        //}
    }
}